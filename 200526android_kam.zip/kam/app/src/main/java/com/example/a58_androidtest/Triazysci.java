package com.example.a58_androidtest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Triazysci extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_triazysci);
    }
}
