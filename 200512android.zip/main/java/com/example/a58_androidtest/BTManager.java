package com.example.a58_androidtest;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.AdvertiseSettings;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanSettings;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.ParcelUuid;
import android.util.Log;
import android.widget.Toast;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.UUID;

import androidx.annotation.RequiresApi;

@RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
public class BTManager {

    //advertising
    AdvertiseSettings advertiserSettings;

    ParcelUuid uuid;
    BluetoothAdapter adapter;
    BluetoothLeAdvertiser advertiser;
    AdvertiseCallback advertisingCallback;

    //discovering
    BluetoothLeScanner mBluetoothLeScanner;
    Handler mHandler = new Handler();
    ScanFilter scanFilter;
    ScanSettings scanSettings;
    ArrayList<ScanFilter> filters = new ArrayList<ScanFilter>();

    Integer advertiserStatus = 0; //0 - free; 1 - busy


    //ex: "00000000-0000-1000-8000-00805F9B34FB"
    public BTManager(String _uuid){
        setUuid(_uuid);
    }

    public void setUuid(String _uuid){
        uuid = ParcelUuid.fromString("a2f6c84c-43fa-483d-a714-9ba8bfa657e3");
        //uuid = new ParcelUuid(UUID.nameUUIDFromBytes(byte_name));
    }

    public void init(String devName) throws Exception {
        adapter = BluetoothAdapter.getDefaultAdapter();

        //check if device supports bt
        if (adapter == null) {
            // Device doesn't support Bluetooth
            throw(new Exception("Device doesn't support Bluetooth"));
        }

        //ask user to run bt
        if (!adapter.isEnabled()) {
            throw(new Exception("Bluetooth is not enabled"));
        }

        adapter.setName(devName);
        advertiser = adapter.getBluetoothLeAdvertiser();
        mBluetoothLeScanner = adapter.getBluetoothLeScanner();

        advertiserSettings = new AdvertiseSettings.Builder()
            .setAdvertiseMode( AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY )
            .setTxPowerLevel( AdvertiseSettings.ADVERTISE_TX_POWER_HIGH )
            .setConnectable( false )
            .build();
    }


    //max frame size is 31 bytes
    public void sendPing(){
        ByteBuffer bb = ByteBuffer.allocate(1);
        bb.put((byte) 1); //add ping code
        //bb.put((byte) 48); //add ping code
        //bb.put((byte) 49); //add ping code
        //bb.put((byte) 50); //add ping code
        //bb.put((byte) 51); //add ping code
        bb.putLong(uuid.getUuid().getMostSignificantBits()); //add higher part of uuid
        bb.putLong(uuid.getUuid().getLeastSignificantBits()); //add lower part of uuid

        //ParcelUuid _uuid = ParcelUuid.fromString("00000000-0000-1000-8000-00805F9B34FB");

        //ParcelUuid _uuid2 = new ParcelUuid(UUID.randomUUID());

        AdvertiseData data = (new AdvertiseData.Builder()) //build request
            .setIncludeDeviceName(true)
            .addServiceData(new ParcelUuid(UUID.randomUUID()), bb.array()) //add data for broadcast request
            //.addServiceData(new ParcelUuid(UUID.randomUUID()), bb.array()) //add data for broadcast request
            .build();

        /*AdvertiseData data = (new AdvertiseData.Builder()).addServiceData(new
                        ParcelUuid(UUID.randomUUID()),
                "You should be able to fit large amounts of data up to maxDataLength. This goes up to 1650 bytes. For legacy advertising this would not work".getBytes()).build();
        */

        /*AdvertiseData data = new AdvertiseData.Builder()
                .setIncludeDeviceName( false )
                .addServiceUuid( _uuid )
                .addServiceData( _uuid, "Data".getBytes( Charset.forName( "UTF-8" ) ) )
                .build();*/

        send(data);
    }

    public void send(AdvertiseData data){
            advertisingCallback = new AdvertiseCallback() {
            @Override
            public void onStartSuccess(AdvertiseSettings settingsInEffect) {
                super.onStartSuccess(settingsInEffect);
                //stop advertising after frame send
                if(advertiserStatus  == 1) {
                    advertiserStatus = 0;
                    advertiser.stopAdvertising(advertisingCallback);
                }
            }

            @Override
            public void onStartFailure(int errorCode) {
                super.onStartFailure(errorCode);
                System.out.println("onStartFailure: errorCode: " + errorCode);
            }
        };

        //stop advertising after 0.5s
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if(advertiserStatus  == 1) {
                    advertiserStatus = 0;
                    advertiser.stopAdvertising(advertisingCallback);
                }
            }
        }, 1000);

        advertiser.startAdvertising(advertiserSettings, data, advertisingCallback);
        advertiserStatus = 1;
    }

    public void receive(){

    }

}
